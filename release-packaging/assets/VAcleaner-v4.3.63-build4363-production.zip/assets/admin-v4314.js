/* VAcleaner v4.3.14 — admin exact-time bottom sheet.
   Keeps canonical pickupTime/returnTime inputs for existing business logic,
   while moving the 30-minute choice UI out of the booking form on iPhone/PWA. */
(() => {
  'use strict';

  const STEP_MINUTES = 30;
  const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
  const allTimes = [];
  let active = null;
  let overlay = null;
  let sheet = null;
  let grid = null;
  let title = null;
  let closeButton = null;

  for (let hour = 0; hour < 24; hour += 1) {
    for (let minute = 0; minute < 60; minute += STEP_MINUTES) {
      allTimes.push(`${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`);
    }
  }

  function validTime(value) {
    return TIME_RE.test(String(value || ''));
  }

  function isGridTime(value) {
    return validTime(value) && Number(String(value).slice(3, 5)) % STEP_MINUTES === 0;
  }

  function contextTitle(input) {
    return input.name === 'returnTime' ? 'Оберіть час повернення' : 'Оберіть час видачі';
  }

  function hideLegacyTimeUI(input) {
    const wrapper = input.closest('.admin-exact-time-picker');
    const moment = input.closest('.rental-moment');
    wrapper?.querySelector('.admin-time-tariff-hint')?.setAttribute('aria-hidden', 'true');
    if (!moment) return;
    const label = input.name === 'returnTime' ? 'Вікно повернення' : 'Вікно видачі';
    [...moment.querySelectorAll('span,label,div,p')].forEach(node => {
      if (node === input || node.contains(input)) return;
      if (node.children.length === 0 && node.textContent.trim() === label) {
        node.classList.add('admin-v4314-hide-window-label');
      }
    });
  }

  function updateTrigger(input, trigger) {
    const value = validTime(input.value) ? input.value : '08:00';
    const valueNode = trigger.querySelector('.admin-v4314-time-value');
    if (valueNode) valueNode.textContent = value;
  }

  function makeOption(time, current, offGrid = false) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `admin-v4314-time-option${offGrid ? ' admin-v4314-current-off-grid' : ''}`;
    button.dataset.time = time;
    button.textContent = offGrid ? `Поточний час · ${time}` : time;
    const selected = time === current;
    button.classList.toggle('is-selected', selected);
    button.setAttribute('aria-pressed', selected ? 'true' : 'false');
    button.addEventListener('click', event => {
      event.preventDefault();
      if (!active) return;
      active.input.value = time;
      active.input.dispatchEvent(new Event('input', {bubbles: true}));
      active.input.dispatchEvent(new Event('change', {bubbles: true}));
      updateTrigger(active.input, active.trigger);
      closeSheet(true);
    });
    return button;
  }

  function ensureSheet() {
    if (overlay) return;
    overlay = document.createElement('div');
    overlay.className = 'admin-v4314-time-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `
      <div class="admin-v4314-time-backdrop" data-time-sheet-close="1"></div>
      <section class="admin-v4314-time-sheet" role="dialog" aria-modal="true" aria-labelledby="adminV4314TimeTitle">
        <header class="admin-v4314-time-sheet-head">
          <div>
            <strong id="adminV4314TimeTitle"></strong>
            <small>Крок 30 хв</small>
          </div>
          <button type="button" class="admin-v4314-time-close" aria-label="Закрити вибір часу">×</button>
        </header>
        <div class="admin-v4314-time-scroll">
          <div class="admin-v4314-time-grid" role="listbox"></div>
        </div>
      </section>`;
    document.body.appendChild(overlay);
    sheet = overlay.querySelector('.admin-v4314-time-sheet');
    grid = overlay.querySelector('.admin-v4314-time-grid');
    title = overlay.querySelector('#adminV4314TimeTitle');
    closeButton = overlay.querySelector('.admin-v4314-time-close');

    overlay.querySelector('[data-time-sheet-close="1"]').addEventListener('click', () => closeSheet(false));
    closeButton.addEventListener('click', () => closeSheet(false));
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && active) closeSheet(false);
    });
  }

  function closeSheet(returnFocus) {
    if (!overlay || !active) return;
    const trigger = active.trigger;
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    document.documentElement.classList.remove('admin-v4314-time-sheet-open');
    document.body.classList.remove('admin-v4314-time-sheet-open');
    trigger.setAttribute('aria-expanded', 'false');
    active = null;
    if (returnFocus) requestAnimationFrame(() => trigger.focus({preventScroll: true}));
  }

  function openSheet(input, trigger) {
    ensureSheet();
    const current = validTime(input.value) ? input.value : '08:00';
    if (!validTime(input.value)) input.value = current;

    active = {input, trigger};
    title.textContent = contextTitle(input);
    grid.replaceChildren();
    if (!isGridTime(current)) grid.appendChild(makeOption(current, current, true));
    allTimes.forEach(time => grid.appendChild(makeOption(time, current)));

    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('admin-v4314-time-sheet-open');
    document.body.classList.add('admin-v4314-time-sheet-open');
    trigger.setAttribute('aria-expanded', 'true');

    requestAnimationFrame(() => {
      const selected = grid.querySelector('.admin-v4314-time-option.is-selected');
      selected?.scrollIntoView({block: 'center', behavior: 'auto'});
      closeButton?.focus({preventScroll: true});
    });
  }

  function upgrade(input) {
    if (!(input instanceof HTMLInputElement) || input.dataset.v4314Time === '1') return;
    if (!['pickupTime', 'returnTime'].includes(input.name)) return;
    const wrapper = input.closest('.admin-exact-time-picker');
    if (!wrapper) return;

    input.dataset.v4314Time = '1';
    input.classList.add('admin-v4314-native-time');
    input.dataset.originalType = input.type;
    try { input.type = 'hidden'; } catch (_) {}
    input.tabIndex = -1;
    input.setAttribute('aria-hidden', 'true');

    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'admin-v4314-time-trigger';
    trigger.setAttribute('aria-haspopup', 'dialog');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.innerHTML = '<span class="admin-v4314-time-value"></span>';
    trigger.addEventListener('click', event => {
      event.preventDefault();
      event.stopPropagation();
      openSheet(input, trigger);
    });

    input.addEventListener('input', () => updateTrigger(input, trigger));
    input.addEventListener('change', () => updateTrigger(input, trigger));
    input.form?.addEventListener('reset', () => setTimeout(() => updateTrigger(input, trigger), 0));

    wrapper.appendChild(trigger);
    hideLegacyTimeUI(input);
    updateTrigger(input, trigger);
  }

  function scan(root = document) {
    root.querySelectorAll?.('.admin-exact-time-picker input[name="pickupTime"], .admin-exact-time-picker input[name="returnTime"]').forEach(upgrade);
  }

  function boot() {
    scan();
    const observer = new MutationObserver(records => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches?.('.admin-exact-time-picker input[name="pickupTime"], .admin-exact-time-picker input[name="returnTime"]')) upgrade(node);
          scan(node);
        }
      }
    });
    observer.observe(document.body, {childList: true, subtree: true});
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once: true});
  else boot();
})();
